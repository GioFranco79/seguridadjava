package com.edutecno.model;

public enum Role {
	ADMIN, USER
}
